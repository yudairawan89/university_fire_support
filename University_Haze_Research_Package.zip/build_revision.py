from pathlib import Path
import json,re,copy,zipfile,io
from collections import OrderedDict
from docx import Document
from docx.shared import Pt,Inches,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from PIL import Image
R=Path(__file__).resolve().parent;O=R/'outputs';src=R/'inputs/University_Haze_Revised_Springer_Q1(1).docx';d=Document(src);ps=list(d.paragraphs)
urls={}
for p in ps:
 for h in p._p.xpath('.//w:hyperlink'):
  text=''.join(h.xpath('.//w:t/text()'));rid=h.get(qn('r:id'))
  if re.fullmatch(r'\[\d+\]',text) and rid in d.part.rels:urls[int(text[1:-1])]=d.part.rels[rid].target_ref
raw0=(R/'inputs/University_Haze_References_Complete_53.ris').read_text(encoding='utf-8-sig')
rr0=re.findall(r'TY  - .*?ER  -[^\n]*(?:\n|$)',raw0,re.S)
for i,r in enumerate(rr0,1):
 u=re.search(r'^UR  - (.+)$',r,re.M);doi=re.search(r'^DO  - (.+)$',r,re.M)
 if u:urls.setdefault(i,u[1].strip())
 elif doi:urls.setdefault(i,'https://doi.org/'+doi[1].strip())
extras=[
('IPB University','IPB University Fasilitasi Pelatihan Pemadaman Kebakaran Gambut Langsung di Ketapang, Kalbar',2025,'https://www.ipb.ac.id/news/index/2025/05/ipb-university-fasilitasi-pelatihan-pemadaman-kebakaran-gambut-langsung-di-ketapang-kalbar/'),
('Universitas Jambi','Kegiatan Forest and Land Fire Management yang Diselenggarakan KIFC dan Manggala Agni Jambi',2024,'https://pertanian.unja.ac.id/kegiatan-forest-and-land-fire-management-yang-diselenggarakan-kifc-korea-indonesia-forest-center-dan-manggala-agni-jambi-disambut-antusias-mahasiswa-kehutanan-universtas-jambi/'),
('Dini Arista, Desri Maulina Sari, Anggun Budiastuti, and Rahmatillah Razak','Upaya Preventif Peningkatan Risiko TB Paru Akibat Kabut Asap dengan Pemanfaatan Masker dan Pemberian Edukasi kepada Masyarakat di Kecamatan Jejawi Kabupaten Ogan Komering Ilir Sumatera Selatan',2020,'https://doi.org/10.37061/jps.v8i1.12411'),
('Universitas Gadjah Mada','Masalah Kabut Asap Perlu Dianalisis dalam Perspektif Asia Tenggara',2016,'https://ugm.ac.id/id/berita/12768-masalah-kabut-asap-perlu-dianalisis-dalam-perspektif-asia-tenggara/'),
('Hidayati','KHDTK ULM Adakan Penyuluhan dan Pelatihan Teknik Pembukaan Lahan Tanpa Bakar dalam Rangka Pencegahan Karhutla',2021,'https://khdtk.ulm.ac.id/2021/11/01/khdtk-ulm-adakan-penyuluhan-dan-pelatihan-teknik-pembukaan-lahan-tanpa-bakar-pltb-dalam-rangka-pencegahan-karhutla-pltb/'),
('Universitas Sebelas Maret','UPT PPK UNS Ikut Berpartisipasi dalam Operasi Karhutla di Gunung Lawu',2023,'https://uns.ac.id/id/uns-update/upt-ppk-uns-ikut-berpartisipasi-dalam-operasi-karhutla-di-gunung-lawu.html')]
for i,x in enumerate(extras,54):urls[i]=x[3]
bib={int(re.match(r'\[(\d+)\]',p.text)[1]):p.text for p in ps[117:]}
for i,(author,title,year,url) in enumerate(extras,54):
 bib[i]=f'[{i}] {author}, “{title},” '+('Jurnal Pengabdian Sriwijaya, vol. 8, no. 1, pp. 940–944, 2020, doi: 10.37061/jps.v8i1.12411.' if i==56 else f'{"Universitas Lambung Mangkurat" if i==58 else author}, {year}. [Online]. Available: {url}. Accessed: October 31, 2026.')
# Rebuild changed paragraphs while retaining paragraph properties and template identity.
def clear(p):
 for c in list(p._p):
  if c.tag!=qn('w:pPr'):p._p.remove(c)
def link(p,text,url):
 h=OxmlElement('w:hyperlink');h.set(qn('r:id'),p.part.relate_to(url,RT.HYPERLINK,is_external=True));r=OxmlElement('w:r');pr=OxmlElement('w:rPr');col=OxmlElement('w:color');col.set(qn('w:val'),'0000FF');pr.append(col);sz=OxmlElement('w:sz');sz.set(qn('w:val'),'22');pr.append(sz);r.append(pr);t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);p._p.append(h)
def textfill(p,text):
 clear(p);pos=0
 for z in re.finditer(r'\[(\d+)\]',text):
  p.add_run(text[pos:z.start()]);link(p,z.group(),urls[int(z[1])]);pos=z.end()
 p.add_run(text[pos:])
for ix,t in json.loads((R/'revisions.json').read_text()).items():textfill(ps[int(ix)],t)
textfill(ps[3],'2 Department of Computer Science, Faculty of Computer Science, Universitas Hang Tuah Pekanbaru, Pekanbaru, Indonesia')
textfill(ps[4],'3 Department of Master of Public Health, Faculty of Public Health, Universitas Hang Tuah Pekanbaru, Pekanbaru, Indonesia')
# Keep the conclusion in two complete paragraphs without an orphaned final line.
ps[102]._element.getparent().remove(ps[102]._element)
# Preserve original figures 1 and 2; replace computed figure parts 3–5.
for shape,n in zip(list(d.inline_shapes)[2:],[3,4,5]):
 p=O/f'Figure_{n}.png';rid=shape._inline.xpath('.//a:blip')[0].get(qn('r:embed'));d.part.related_parts[rid]._blob=p.read_bytes()
 with Image.open(p) as im:w,h=im.size
 shape.width=Inches(6.5);shape.height=int(shape.width*h/w)
# Data table remains the third table of the supplied template.
rows=[['Dimension','Characteristic','Count or ratio','Percent'],['Corpus','Program episodes','34','100.0'],['Corpus','Original source URLs','33','—'],['Corpus','Numerical indicator records','46','—'],['Implementation','Implemented delivery','29/34','85.3'],['Source access','Direct webpage or full PDF','29/34','85.3'],['Numerical reporting','Episodes with an indicator','21/34','61.8'],['Timing','Activity year identifiable','27/34','79.4'],['Location','Riau','14/34','41.2'],['Location','Central Kalimantan','4/34','11.8'],['Location','Jambi','4/34','11.8'],['Location','West Kalimantan','3/34','8.8'],['Location','Other named provinces','7/34','20.6'],['Location','Province not specified','2/34','5.9'],['Outcome reporting','Learning assessment','5/18','27.8'],['Outcome reporting','Explicit pre–post learning design','4/18','22.2'],['Outcome reporting','Numerical exposure measurement','1/3','33.3'],['Outcome reporting','Measured clinical endpoint','0/4','0.0']]
for row,values in zip(d.tables[2].rows,rows):
 for c,t in zip(row.cells,values):c.text=t
# Re-number citations by first occurrence, including table text.
order=[]
for el in d._element.body:
 if el is ps[116]._p:break
 for p in el.iter(qn('w:p')):
  txt=''.join(p.itertext()) if False else ''.join(p.xpath('.//w:t/text()'))
  for x in re.findall(r'\[(\d+)\]',txt):
   k=int(x)
   if k not in order:order.append(k)
assert len(order)==59,(len(order),set(range(1,60))-set(order))
remap={old:i for i,old in enumerate(order,1)}
for el in d._element.body:
 if el is ps[116]._p:break
 for t in el.iter(qn('w:t')):
  if t.text:t.text=re.sub(r'\[(\d+)\]',lambda z:f'[{remap[int(z[1])]}]',t.text)
# Link every numeric citation in the article body, including previously plain citations.
oldurls=urls.copy();urls={remap[k]:v for k,v in oldurls.items()}
from docx.text.paragraph import Paragraph
for el in d._element.body:
 if el is ps[116]._p:break
 for pe in list(el.iter(qn('w:p'))):
  txt=''.join(pe.xpath('.//w:t/text()'))
  if re.search(r'\[\d+\]',txt):textfill(Paragraph(pe,d),txt)
urls=oldurls
# Remove old bibliography only; append complete entries with original metadata.
for p in ps[117:]:p._element.getparent().remove(p._element)
for old in order:
 t=re.sub(r'^\[\d+\]',f'[{remap[old]}]',bib[old]);p=d.add_paragraph();p.paragraph_format.first_line_indent=Inches(-.25);p.paragraph_format.left_indent=Inches(.25)
 # Keep the full author list. Hyperlink DOI/URL text without modifying bibliographic titles.
 url=urls.get(old,'');doi=url.split('doi.org/')[-1] if 'doi.org/' in url else ''
 needle=doi if doi and doi.lower() in t.lower() else (url if url in t else '')
 if needle:
  start=t.lower().index(needle.lower());p.add_run(t[:start]);link(p,t[start:start+len(needle)],url);p.add_run(t[start+len(needle):])
 else:p.add_run(t)
# Template typography and table rules.
for p in d.paragraphs:
 p.paragraph_format.line_spacing=1.15
 if p._p.xpath('.//w:drawing'):continue
 txt=p.text.strip();heading=(p not in d.paragraphs[:6] and bool(re.match(r'^\d+(?:\.\d+)*\s',txt))) or txt in ['Abstract','Declarations','Funding','Competing interests','Ethics and consent','Data and code availability','Author contributions','Acknowledgment of generative AI assistance','References']
 caption=bool(re.match(r'^(?:Table|Fig\.)\s\d+',txt))
 if not caption and not heading and p not in d.paragraphs[:6] and not p._p.xpath('.//m:oMath'):
  p.style=d.styles['Normal']
 if caption:
  clear(p);z=re.match(r'^((?:Table|Fig\.)\s\d+)(.*)$',txt);p.add_run(z[1]).bold=True;p.add_run(z[2]).bold=False;p.paragraph_format.first_line_indent=Inches(0)
 elif heading:p.paragraph_format.first_line_indent=Inches(0);p.paragraph_format.keep_with_next=True
 elif p is not d.paragraphs[0] and not txt.startswith('[') and p not in d.paragraphs[1:6]:
  p.paragraph_format.first_line_indent=Inches(.25)
  for t in p._p.xpath('.//w:t'):
   if t.text:t.text=t.text.lstrip('\t')
 for run in p.runs:
  run.font.name='Times New Roman';run.font.size=Pt(12 if p==d.paragraphs[0] else 11)
  if heading:run.bold=True;run.font.color.rgb=RGBColor(0,0,0)
  elif not caption and p!=d.paragraphs[0]:run.bold=False
for t in d.tables:
 pr=t._tbl.tblPr
 for b in list(pr.findall(qn('w:tblBorders'))):pr.remove(b)
 b=OxmlElement('w:tblBorders')
 for s in ['top','bottom','left','right','insideH','insideV']:
  e=OxmlElement('w:'+s);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'5');e.set(qn('w:color'),'000000');b.append(e)
 pr.append(b)
 for i,row in enumerate(t.rows):
  rpr=row._tr.get_or_add_trPr();cs=OxmlElement('w:cantSplit');rpr.append(cs)
  if i==0:
   hdr=OxmlElement('w:tblHeader');rpr.append(hdr)
  for cell in row.cells:
   for p in cell.paragraphs:
    p.paragraph_format.line_spacing=1.15;p.paragraph_format.first_line_indent=Inches(0);p.paragraph_format.space_after=Pt(2)
    for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(10);r.bold=i==0
# Avoid leaving only one data row at the bottom of a page.
for row in d.tables[2].rows[:3]:
 for c in row.cells:
  for p in c.paragraphs:p.paragraph_format.keep_with_next=True
# Standardize affiliation markers without changing author names or affiliations.
ap=d.paragraphs[1];clear(ap);ap.style=d.styles['Normal'];ap.paragraph_format.first_line_indent=Inches(0)
for j,(name,marker) in enumerate([('Nopriadi','1*'),('Yuda Irawan','2'),('Emy Leonita','3')]):
 if j:ap.add_run(', ')
 ap.add_run(name);rr=ap.add_run(marker);rr.font.superscript=True
for j in [2,3,4]:
 ap=d.paragraphs[j];txt=ap.text.strip();clear(ap);ap.style=d.styles['Normal'];ap.paragraph_format.first_line_indent=Inches(0);ap.paragraph_format.keep_with_next=False
 rr=ap.add_run(txt[0]);rr.font.superscript=True;ap.add_run(' '+txt[1:].strip())
 for rr in ap.runs:rr.bold=False;rr.font.name='Times New Roman';rr.font.size=Pt(11)
d.paragraphs[0].style=d.styles['Title']
for run in d.paragraphs[0].runs:
 run.font.name='Times New Roman';run.font.size=Pt(12);run.bold=True;run.font.color.rgb=RGBColor(0,0,0)
# A source document's approval assertion is not reproduced without author confirmation.
d.core_properties.title=ps[0].text
out=O/'University_Haze_Final_Manuscript.docx';d.save(out)
# Preserve original editing-time/application metadata exactly.
with zipfile.ZipFile(src) as z:app=z.read('docProps/app.xml')
with zipfile.ZipFile(out) as z:entries={n:z.read(n) for n in z.namelist()}
entries['docProps/app.xml']=app
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,v in entries.items():z.writestr(n,v)
# RIS: retain original 53 records; add source records and re-order with citations.
raw=(R/'inputs/University_Haze_References_Complete_53.ris').read_text(encoding='utf-8-sig');records=re.findall(r'TY  - .*?ER  -[^\n]*(?:\n|$)',raw,re.S);assert len(records)==53,len(records)
for idx,(author,title,year,url) in enumerate(extras,54):
 if idx==56:au=['Arista, Dini','Sari, Desri Maulina','Budiastuti, Anggun','Razak, Rahmatillah'];typ='JOUR'
 else:au=[author+','];typ='ELEC'
 r='TY  - '+typ+'\n'+''.join('AU  - '+x+'\n' for x in au)+f'TI  - {title}\nPY  - {year}\n'
 if idx==56:r+='JO  - Jurnal Pengabdian Sriwijaya\nVL  - 8\nIS  - 1\nSP  - 940\nEP  - 944\nDO  - 10.37061/jps.v8i1.12411\n'
 else:r+='PB  - '+('Universitas Lambung Mangkurat' if idx==58 else author)+'\n'
 records.append(r+f'UR  - {url}\nER  -\n')
(O/'University_Haze_References_59.ris').write_text('\n'.join(records[k-1] for k in order))
words=len(re.findall(r'\S+',' '.join(d._element.xpath('.//w:t/text()'))));report={'words':words,'citations':len(order),'tables':len(d.tables),'figures':len(d.inline_shapes),'equations':len(d._element.xpath('.//m:oMath')),'editing_minutes_preserved':True,'independent_dual_coding_completed':False}
(R/'build_report.json').write_text(json.dumps(report,indent=2));print(report)
