"""Create source-linked decision records; this is assisted review, not a second rater."""
from pathlib import Path
import pandas as pd,json
R=Path(__file__).resolve().parents[1]; O=R/'outputs'
d=pd.read_csv(O/'University_Haze_Expanded_34_Episodes.csv').fillna('')
old=pd.read_csv(R/'inputs/University_Haze_PreReview_34_Episodes.csv').set_index('record_id')
roles=[c for c in d if c.startswith('role_') and c.endswith('_reported')]
# Paraphrases of episode-specific passages, not verbatim source quotations.
a={
'UH001':{0:'Free medical service specified for 3–10 September.',1:'Distribution of 1,500 masks reported.'},
'UH002':{0:'University hospital directed to maintain around-the-clock emergency readiness.',7:'Classes suspended for 7–9 September by institutional decision.'},
'UH003':{1:'Volunteer post received N95 masks, portable oxygen and vitamins.',5:'Post supplied operational support to fire-response volunteers; no direct firefighting deployment inferred.'},
'UH004':{0:'Report records examination of 204 patients and medication provision.',1:'Report lists 1,500 N95 masks among response outputs.',2:'Report lists ten air purifiers as response equipment.',3:'Health education and leaflets are included in the response activities.',6:'CO and oxygen measurement activities appear in the schedule; no numerical pollutant result reported.',7:'Coordination with government and partner institutions described.'},
'UH005':{1:'Alumni-partner relief distributed N95 masks, oxygen and other supplies; proposed medical checks not counted as delivered care.'},
'UH006':{2:'School classroom protection-room trial described.',6:'Indoor PM10 of 70–80 and outdoor PM10 of 180 micrograms per cubic metre reported.'},
'UH007':{2:'Zeta Green device developed for cleaner indoor air; no operational evaluation inferred.',6:'Air-cleaner development and associated technical research described.'},
'UH008':{8:'KKN across 60 villages linked with seedling support for the same village scope.'},
'UH009':{1:'DERU supplied 800 N95 masks, nebulizers and medicines through relief partners; no patient care inferred from donation.'},
'UH010':{0:'First aid, oxygen, medicines and evacuation transport described.',1:'Clinic response included protective mask provision.'},
'UH011':{1:'Free masks distributed in the community activity.',3:'Lecturers delivered haze-health and self-protection information.'},
'UH012':{1:'Students distributed free masks to road users; mask class and quantity unspecified.'},
'UH013':{5:'Thirteen students joined BPBD actual-fire cooling operations.'},
'UH014':{4:'University participants joined forest-fire prevention and response training.'},
'UH015':{7:'Six higher-education leaders signed police cooperation agreements at a post launch; operation not inferred.'},
'UH016':{3:'Social-media posters and webinar provided fire-risk education.',8:'Community greening and seedling planting reported.'},
'UH017':{4:'Technical preparedness instruction and mentoring for fire-information dashboard described.',6:'Tableau dashboard supported fire-information presentation and decision support; field impact not quantified.'},
'UH018':{3:'Haze-health instruction delivered to 35 pupils; pre/post knowledge results reported.'},
'UH019':{7:'University and police discussed future research and village fire-prevention cooperation; planning retained as planning.'},
'UH020':{3:'Fire prevention and no-burn preparation information delivered.',4:'Hands-on extinguisher demonstration and fire-prevention training described.',8:'No-burn land preparation taught as an upstream prevention practice.'},
'UH021':{3:'Community socialization explained fire risks and prevention.',4:'Explicit fire-prevention and control instruction qualifies under the training definition; hands-on simulation not inferred.'},
'UH022':{3:'Instruction explained organic alternatives in a fire-affected peatland community.',8:'Organic farming, eco-enzymes and biopesticide practices linked to peatland livelihood management; not classified as fire-response skills.'},
'UH023':{3:'Article explicitly describes fire-control education involving 500 students.',4:'Controlled simulation and water-bombing demonstration described; no actual-fire deployment inferred.'},
'UH024':{3:'Community fire-prevention socialization described.',4:'Technical preparedness and response-capacity training described.',8:'Community capacity activities linked to no-burn land management.'},
'UH025':{4:'Facilitation of no-burn land preparation training described.',6:'Daily hotspot monitoring with FIELD Indonesia described.',7:'Institutional coordination and national recognition linked to the monitoring program.'},
'UH026':{7:'Twenty-five nursing students participated in a national readiness assembly; emergency deployment not inferred.'},
'UH027':{3:'Talkshow communicated fire-prevention information.',4:'Student volunteer fire simulation conducted.',7:'Volunteer launch and signed implementation agreement documented.'},
'UH028':{3:'Residents received peat-fire and smoke-risk instruction.',4:'Demonstration and simulation for 20 residents described.'},
'UH029':{3:'Expert instruction covered peat-fire prevention and suppression.',4:'Nineteen participants undertook dry simulation and controlled training burns.',6:'Environmental fire-behaviour observations and thermal-camera recording described; not human-exposure measurements.'},
'UH030':{4:'At least 31 forestry students joined forest and land fire management training.'},
'UH031':{1:'N95 protection explained and masks supplied during haze-health education.',3:'Community education included pre/post assessment of 24 respondents; narrative beneficiary count was 50.'},
'UH032':{6:'Peat-fire early-warning application presented; field use not demonstrated.',7:'Strategic policy focus-group dialogue convened; implementation not inferred.'},
'UH033':{3:'Community instruction addressed the harms of burning and alternatives.',4:'No-burn preparation and compost practical training described.',8:'Compost and no-burn livelihood practices addressed land management.'},
'UH034':{5:'MPA/SRU teams deployed during the Gunung Lawu fire.',6:'A hotspot-mapping team supported the deployment.'}}
rows=[]
for _,r in d.iterrows():
 for j,c in enumerate(roles):
  v=int(r[c]); prev=int(old.loc[r.record_id,c]);support=a[r.record_id].get(j,'')
  assert bool(support)==bool(v),(r.record_id,c)
  rows.append(dict(record_id=r.record_id,role=c,original_code=prev,reviewed_code=v,decision_status='changed' if v!=prev else 'retained',supporting_passage_paraphrase=support or 'No explicit episode-specific support identified in the examined source material.',source_url=r.source_url,source_access=r.source_access,source_locator=r.source_locator,rationale='Positive documentary evidence under the operational role definition.' if v else 'Code 0 means not documented in examined material; it is not confirmed absence of activity.',reviewed_on='2026-10-31',review_method='Source-linked assisted review; not independent human duplicate coding'))
pd.DataFrame(rows).to_csv(O/'University_Haze_Coding_Decisions_306.csv',index=False)
changes=[]
for _,r in d.iterrows():
 for c in roles+['source_access']:
  prev=old.loc[r.record_id,c]; now=r[c]
  if str(prev)!=str(now):
   why={'UH008':'Separate institution-wide education bullet cannot be assigned to the KKN episode.','UH023':'Primary report explicitly names fire-control education in addition to simulation.'}.get(r.record_id,'Complete primary institutional article text accessed; source-access category updated.')
   changes.append(dict(record_id=r.record_id,field=c,previous_value=prev,reviewed_value=now,reason=why,source_url=r.source_url,reviewed_on='2026-10-31'))
pd.DataFrame(changes).to_csv(O/'University_Haze_Decision_Changes.csv',index=False)
labels=['Healthcare','Protective supplies','Clean air','Risk education','Prevention training','Fire response','Monitoring and research','Governance','Land management']
defs=[('Consultation, examination, referral, clinical support or explicit clinical readiness','Supplies donated to a hospital alone do not show patient care.'),('Specified protective supplies received or distributed','Receipt, distribution and proposed delivery remain distinct.'),('Room or device explicitly intended to reduce inhaled smoke','Device prototype does not establish operational use.'),('Information on fire, haze, health risk or protective action','A separate institution-wide education bullet is not automatically assigned to a named program.'),('Practical preparedness, simulation or explicit fire-prevention instruction','Land-management training alone is not automatically training for fire prevention; intended curriculum must support it.'),('Actual-fire deployment or operational support to responders','Controlled burns or simulations alone do not establish emergency deployment.'),('Measurement, surveillance, decision support or applied research','Fire-behaviour and hotspot measurements do not establish human-exposure outcomes.'),('Institutional policy, agreement, coordination or formal preparedness','A meeting, agreement or ceremony is not necessarily operating delivery.'),('Restoration or livelihood practice linked to prevention or recovery','Expected benefits do not establish a measured ecological or health effect.')]
pd.DataFrame([dict(variable=c,label=l,positive_rule=z[0],boundary_rule=z[1],zero_definition='Not explicitly documented in the examined material; not proof of absence.') for c,l,z in zip(roles,labels,defs)]).to_csv(O/'University_Haze_Coding_Protocol.csv',index=False)
# Outcome classification carries original design and denominator notes.
cols=['record_id','education_eligible','exposure_eligible','clinical_eligible','learning_result','explicit_pre_post','exposure_result','clinical_result','evaluation_design','reported_findings','extraction_notes','source_url','source_access']
d[cols].to_csv(O/'University_Haze_Outcome_Decisions.csv',index=False)
assert len(rows)==306 and sum(r['reviewed_code'] for r in rows)==67 and len(changes)==5
print(json.dumps({'decisions':len(rows),'positive':67,'changed_roles':2,'access_upgrades':3},indent=2))
