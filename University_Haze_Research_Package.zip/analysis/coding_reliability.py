"""Compare genuinely independent coding files before reconciliation.
Usage: python coding_reliability.py coder1.csv coder2.csv output.csv
No reliability result is generated from an incomplete second-coder file.
"""
import sys,pandas as pd,numpy as np
A=pd.read_csv(sys.argv[1]);B=pd.read_csv(sys.argv[2]);cols=[c for c in A if c.startswith('role_') and c.endswith('_reported')]
assert A.record_id.is_unique and B.record_id.is_unique
assert set(A.record_id)==set(B.record_id),'Episode sets must match'
A=A.set_index('record_id');B=B.set_index('record_id').loc[A.index];out=[]
for c in cols:
 a=pd.to_numeric(A[c],errors='coerce');b=pd.to_numeric(B[c],errors='coerce')
 if a.isna().any() or b.isna().any():raise ValueError('Independent coding incomplete: '+c)
 assert a.isin([0,1]).all() and b.isin([0,1]).all()
 n=len(a);agree=(a==b).mean();pe=a.mean()*b.mean()+(1-a.mean())*(1-b.mean());k=(agree-pe)/(1-pe) if pe<1 else np.nan
 both=((a==1)&(b==1)).sum();den=a.sum()+b.sum()
 out.append(dict(role=c,N=n,agreement_percent=100*agree,kappa=k,positive_agreement=2*both/den if den else np.nan,disagreements=int((a!=b).sum())))
pd.DataFrame(out).to_csv(sys.argv[3],index=False)
