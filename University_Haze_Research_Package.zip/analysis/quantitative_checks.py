from pathlib import Path
import pandas as pd,json
R=Path(__file__).resolve().parents[1];O=R/'outputs'
d=pd.read_csv(O/'University_Haze_Expanded_34_Episodes.csv').set_index('record_id')
f=pd.read_csv(O/'Role_Frequencies.csv');e=pd.read_csv(O/'Outcome_Reporting.csv');m=pd.read_csv(O/'University_Haze_Expanded_46_Indicators.csv')
roles=[c for c in d if c.startswith('role_') and c.endswith('_reported')]
assert len(d)==34 and d.source_url.nunique()==33 and len(m)==46
assert d[roles].isin([0,1]).all().all()
assert d[roles].sum().sum()==67 and d.role_count.ge(2).sum()==23
assert d.education_eligible.sum()==18 and d.learning_result.sum()==5 and d.explicit_pre_post.sum()==4
assert d.direct.sum()==29 and (d.direct&d.delivered).sum()==25
assert not d.clinical_result.any()
assert (d.learning_result<=d.education_eligible).all()
assert (d.exposure_result<=d.exposure_eligible).all()
assert (d.clinical_result<=d.clinical_eligible).all()
for r in f.itertuples():assert abs(r.percent-100*r.count/r.denominator)<1e-9
for r in e.itertuples():
 if r.denominator:assert abs(r.percent-100*r.count/r.denominator)<1e-9
 else:assert pd.isna(r.percent)
rows=[]
for rid,n,pre,post,good0,good1 in [('UH018',35,88.29,96.57,31,33),('UH031',24,70.42,81.67,None,None)]:
 rows.append(dict(record_id=rid,assessment_n=n,pre_mean=pre,post_mean=post,absolute_mean_change=post-pre,relative_mean_change_percent=100*(post-pre)/pre,good_pre=good0,good_post=good1,good_change_percentage_points=100*(good1-good0)/n if good0 is not None else None,source_url=d.loc[rid,'source_url'],design='uncontrolled pre-post',interpretation='Descriptive aggregate contrast; not a causal effect or re-estimated paired test'))
pd.DataFrame(rows).to_csv(O/'Educational_Aggregate_Contrasts.csv',index=False)
pd.DataFrame([dict(record_id='UH006',outdoor_pm10=180,indoor_pm10_min=70,indoor_pm10_max=80,unit='micrograms per cubic metre',spatial_difference_min=100,spatial_difference_max=110,relative_contrast_min_percent=100*100/180,relative_contrast_max_percent=100*110/180,source_url=d.loc['UH006','source_url'],interpretation='Spatial contrast without temporal baseline or untreated comparison; not a causal effectiveness estimate')]).to_csv(O/'Exposure_Aggregate_Contrast.csv',index=False)
pd.DataFrame([dict(subset=s,assessed=int(a.explicit_pre_post.sum()),eligible=int(a.education_eligible.sum()),percent=100*a.explicit_pre_post.sum()/a.education_eligible.sum() if a.education_eligible.sum() else None) for s,a in [('Full',d),('Direct text',d[d.direct]),('Excluding Riau',d[d.activity_province.ne('Riau')])]]).to_csv(O/'Strict_PrePost_Reporting.csv',index=False)
(O/'Numerical_Checks.json').write_text(json.dumps({'passed':True,'episode_integrity':True,'binary_role_integrity':True,'denominator_eligibility':True,'summary_recalculation':True,'individual_records_generated':False},indent=2))
print('Numerical checks passed; aggregate contrasts exported.')
