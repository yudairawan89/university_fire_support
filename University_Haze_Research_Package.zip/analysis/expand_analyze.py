from pathlib import Path
import pandas as pd,numpy as np,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
from PIL import Image
R=Path(__file__).resolve().parents[1];O=R/'outputs'
d=pd.read_csv(R/'inputs/University_Haze_Indonesia_Activities_2015_2025.csv');m=pd.read_csv(R/'inputs/University_Haze_Indonesia_Numeric_Indicators.csv')
roles=[c for c in d if c.startswith('role_')];names=['Healthcare','Protective supplies','Clean air','Risk education','Prevention training','Fire response','Monitoring and research','Governance','Land management']
new=[]
def add(id,hei,province,loc,name,year,date,sy,sd,title,url,access,locator,status,design,pathway,rs,findings,anchor,notes,category):
 row={c:'' for c in d.columns};row.update(record_id=id,lead_hei=hei,activity_province=province,activity_location=loc,activity_name=name,activity_year=year,activity_date=date,activity_date_precision='day' if date else ('year' if year else 'not_reported'),source_year=sy,source_date=sd,source_title=title,source_url=url,source_read_url=url,source_type='journal_article' if access=='pdf_full_text' else 'institutional_news',source_access=access,source_locator=locator,retrieved_date='2026-10-31',target_groups='Program participants',implementation_status=status,evaluation_design=design,public_health_pathway=pathway,reported_findings=findings,evidence_anchor=anchor,extraction_notes=notes,evidence_category=category)
 row.update({c:int(i in rs) for i,c in enumerate(roles)});new.append(row)
add('UH029','IPB University','Kalimantan Barat','Ketapang','Peat-fire suppression field training',2025,'',2025,'2025-05-08','IPB University Fasilitasi Pelatihan Pemadaman Kebakaran Gambut Langsung di Ketapang, Kalbar','https://www.ipb.ac.id/news/index/2025/05/ipb-university-fasilitasi-pelatihan-pemadaman-kebakaran-gambut-langsung-di-ketapang-kalbar/','web_body','Main article paragraphs 1-10','implemented_reported','descriptive_training_report','indirect_prevention',[3,4,6],'Nineteen participants; expert instruction, dry simulation, controlled training burns and environmental measurements. No learning or human exposure result.','Sebanyak 19 orang peserta','Controlled training burns are not emergency fire deployment. Environmental fire-behavior measurements are not human pollutant exposure.','service_output')
add('UH030','Universitas Jambi','Jambi','Manggala Agni Daops Jambi','Forest and land fire management student training',2024,'2024-04-26',2024,'2024-04-27','Kegiatan Forest and Land Fire Management yang Diselenggarakan KIFC dan Manggala Agni Jambi','https://pertanian.unja.ac.id/kegiatan-forest-and-land-fire-management-yang-diselenggarakan-kifc-korea-indonesia-forest-center-dan-manggala-agni-jambi-disambut-antusias-mahasiswa-kehutanan-universtas-jambi/','web_body','Main article paragraphs 1-4','implemented_reported','descriptive_training_report','indirect_prevention',[4],'At least 31 forestry students attended KIFC/Manggala Agni training. No assessed learning result.','31 Mahasiswa','Distinct date, venue and organizers from UH023 (12 June 2024).','service_output')
add('UH031','Universitas Sriwijaya','Sumatera Selatan','Muara Batu/Muara Batun, Jejawi, Ogan Komering Ilir','N95 and haze-health education',2019,'2019-11-26',2020,'','Upaya Preventif Peningkatan Risiko TB Paru Akibat Kabut Asap dengan Pemanfaatan Masker dan Pemberian Edukasi kepada Masyarakat di Kecamatan Jejawi Kabupaten Ogan Komering Ilir Sumatera Selatan','https://ejournal.unsri.ac.id/index.php/jpsriwijaya/article/download/12411/5649','pdf_full_text','pp. 940-944; Table 2 p. 943','implemented_reported','uncontrolled_pre_post','direct_health_education',[1,3],'Report describes 50 beneficiaries; assessment table n=24, mean knowledge 70.42 to 81.67, SD 21.96 and 23.16; reported paired-test p=0.007. No TB or respiratory clinical endpoint.','mean 70,42; 81,67','Beneficiary and assessment denominators differ. Reported SE values do not consistently reconcile with n and SD; SE is not used to reconstruct uncertainty. Village spelling varies.','educational_outcome')
add('UH032','Universitas Gadjah Mada','DI Yogyakarta','Yogyakarta Plaza Hotel','Peat-fire strategic policy dialogue and early-warning demonstration',2016,'2016-11-01',2016,'2016-11-01','Masalah Kabut Asap Perlu Dianalisis dalam Perspektif Asia Tenggara','https://ugm.ac.id/id/berita/12768-masalah-kabut-asap-perlu-dianalisis-dalam-perspektif-asia-tenggara/','web_body','Main article paragraphs 3-10','policy_dialogue_held','descriptive_policy_dialogue','indirect_prevention',[6,7],'PSSAT convened policy dialogue and presented a peat-fire early-warning application. No evaluated policy implementation or measured outcome.','Focus Group Discussion','A held policy discussion is not operational policy delivery. Software presentation is not demonstrated field use.','activity_documented')
add('UH033','Universitas Lambung Mangkurat','Kalimantan Selatan','Mandiangin Timur, Karang Intan, Banjar','No-burn land preparation and compost training','','',2021,'2021-11-01','KHDTK ULM Adakan Penyuluhan dan Pelatihan Teknik Pembukaan Lahan Tanpa Bakar dalam Rangka Pencegahan Karhutla','https://khdtk.ulm.ac.id/2021/11/01/khdtk-ulm-adakan-penyuluhan-dan-pelatihan-teknik-pembukaan-lahan-tanpa-bakar-pltb-dalam-rangka-pencegahan-karhutla-pltb/','web_body','Article intervention and implementation paragraphs','implemented_reported','descriptive_community_service','indirect_prevention',[3,4,8],'No-burn preparation, compost demonstrations and mentoring documented; positive response described without a numerical learning assessment.','pelatihan dan praktek langsung','Publication year is known; activity date not inferred. Expected fire reduction is not a measured effect.','activity_documented')
add('UH034','Universitas Sebelas Maret','Not reported','Gunung Lawu; province of deployment not specified','Forest-fire emergency response and hotspot mapping',2023,'2023-10-01',2023,'2023-10-10','UPT PPK UNS Ikut Berpartisipasi dalam Operasi Karhutla di Gunung Lawu','https://uns.ac.id/id/uns-update/upt-ppk-uns-ikut-berpartisipasi-dalam-operasi-karhutla-di-gunung-lawu.html','indexed_body','Indexed institutional article deployment and team descriptions','deployment_reported','descriptive_deployment_report','indirect_prevention',[5,6],'Deployment of MPA/SRU and a hotspot-mapping team documented. No measured suppression effect or health outcome.','Minggu (1/10/2023)','Direct page exposed sign-in content; indexed institutional text used. Gunung Lawu spans provinces; institution address is not used as deployment province.','activity_documented')
d=pd.concat([d,pd.DataFrame(new)],ignore_index=True)
# Episode-specific source review, 31 October 2026.
# The common institutional summary does not attribute its separate education
# bullet to the national KKN episode. The June UNJA report explicitly describes
# education as well as simulation; its April event remains separate.
d.loc[d.record_id=='UH008','role_risk_education_reported']=0
d.loc[d.record_id=='UH023','role_risk_education_reported']=1
for rid in ['UH005','UH009','UH034']:
 d.loc[d.record_id==rid,'source_access']='web_body'
 d.loc[d.record_id==rid,'source_read_url']=d.loc[d.record_id==rid,'source_url']
 d.loc[d.record_id==rid,'source_locator']='Complete institutional article body, re-accessed 31 October 2026'
d.loc[d.record_id=='UH008','extraction_notes']='KKN and seedling support share the 60-village scope. Separate institution-wide education and healthcare bullets are not attributed to this episode.'
d.loc[d.record_id=='UH023','reported_findings']='The article explicitly describes fire-control education and simulation involving 500 students, including a water-bombing demonstration. No assessed learning or actual-fire deployment result.'
d.loc[d.record_id=='UH023','extraction_notes']='Risk education added after source-specific review. Controlled simulation is retained as training, not actual-fire deployment.'
d.loc[d.record_id=='UH034','extraction_notes']='Complete primary article accessed on 31 October 2026. Gunung Lawu spans provinces; institutional address is not used as deployment province.'
d['reviewed_on']='2026-10-31'
d['coding_review_method']='source-linked assisted consistency review'
d.loc[d.record_id=='UH031','source_doi']='10.37061/jps.v8i1.12411'
d.loc[d.record_id=='UH031','source_date']='2020-03-12'
# Correct source-resolved details already established in the current manuscript.
d.loc[d.record_id=='UH018','reported_findings']='35 pupils; mean score 88.29 to 96.57; good knowledge 31/35 to 33/35. Uncontrolled pre-post; no respiratory or exposure endpoint.'
d.loc[d.record_id=='UH018','extraction_notes']='Original PDF pp. 1145-1151. Mean change 8.28 points; relative change 9.38%; good-knowledge change 5.71 percentage points. Original inferential statistics are not recalculated from aggregate data.'
metrics=[('UH029','training_participants',19,'persons','Reported participants, not knowledge assessments'),('UH029','visiting_fire_experts',3,'persons','French experts supporting training'),('UH030','training_participants_minimum',31,'persons','At least 31 students; lower bound'),('UH031','reported_beneficiaries',50,'persons','Narrative beneficiary count'),('UH031','assessment_sample',24,'persons','Table 2 assessment sample'),('UH031','knowledge_pre_mean',70.42,'score','Pre-intervention mean'),('UH031','knowledge_post_mean',81.67,'score','Post-intervention mean'),('UH031','knowledge_pre_sd',21.96,'score','Reported pre SD'),('UH031','knowledge_post_sd',23.16,'score','Reported post SD'),('UH031','reported_paired_p_value',.007,'probability','Published paired-test p; not recalculated')]
m.loc[m.metric_id=='M024','metric_note']='Relative mean-score increase: (96.57 - 88.29) / 88.29 × 100 = 9.38%; not a percentage-point change in good-knowledge classification. No standardized effect is pooled.'
for i,(id,n,v,u,meaning) in enumerate(metrics,37):
 row={c:'' for c in m};row.update(metric_id=f'M{i:03}',record_id=id,metric_name=n,value=v,unit=u,meaning=meaning,source_locator=d.set_index('record_id').loc[id,'source_locator'],value_origin='reported',metric_note='Beneficiary and assessment denominators kept separate; no individual-level data generated.',source_url=d.set_index('record_id').loc[id,'source_url']);m.loc[len(m)]=row
learn=set(['UH018','UH020','UH021','UH028','UH031']);pre=set(['UH018','UH020','UH028','UH031']);exposure=set(['UH004','UH006','UH007']);clinical=set(['UH001','UH002','UH004','UH010'])
d['education_eligible']=d[roles[3]].eq(1)|d[roles[4]].eq(1);d['exposure_eligible']=d.record_id.isin(exposure);d['clinical_eligible']=d.record_id.isin(clinical);d['learning_result']=d.record_id.isin(learn);d['explicit_pre_post']=d.record_id.isin(pre);d['exposure_result']=d.record_id.eq('UH006');d['clinical_result']=False
d['delivered']=d.implementation_status.isin(['implemented_reported','implemented_policy_reported','pilot_implemented_reported','deployment_reported','training_mentoring_reported']);d['direct']=d.source_access.isin(['web_body','pdf_full_text']);d['numeric']=d.record_id.isin(m.record_id);d['role_count']=d[roles].sum(axis=1)
sets={'Full':np.ones(len(d),bool),'Delivery':d.delivered,'Direct text':d.direct,'Both':d.delivered&d.direct,'Numerical':d.numeric,'Riau':d.activity_province.eq('Riau'),'Excluding Riau':~d.activity_province.eq('Riau')}
rows=[];out=[]
for sn,mask in sets.items():
 a=d[mask];N=len(a)
 for c,n in zip(roles,names):rows.append(dict(subset=sn,role=n,count=int(a[c].sum()),denominator=N,percent=100*a[c].sum()/N))
 for label,elig,res in [('Learning','education_eligible','learning_result'),('Exposure','exposure_eligible','exposure_result'),('Clinical','clinical_eligible','clinical_result')]:
  N=int(a[elig].sum());n=int(a[res].sum());out.append(dict(subset=sn,domain=label,count=n,denominator=N,percent=100*n/N if N else None))
f=pd.DataFrame(rows);e=pd.DataFrame(out)
d.to_csv(O/'University_Haze_Expanded_34_Episodes.csv',index=False);m.to_csv(O/'University_Haze_Expanded_46_Indicators.csv',index=False);f.to_csv(O/'Role_Frequencies.csv',index=False);e.to_csv(O/'Outcome_Reporting.csv',index=False)
pd.DataFrame(new).to_csv(O/'New_Source_Register.csv',index=False)
# Independent-coder form deliberately contains no existing coding decisions.
basecols=['record_id','source_url','source_locator','activity_name','activity_location']
form=d[basecols].copy()
for c in roles+['implementation_status','education_eligible','exposure_eligible','clinical_eligible','learning_result','explicit_pre_post','exposure_result','clinical_result','supporting_quote','coder_name','coding_date']:form[c]=''
form.to_csv(O/'Independent_Coder_Blank.csv',index=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
def save(fig,n):
 buf=io.BytesIO();fig.savefig(buf,format='png',dpi=600,bbox_inches='tight');blob=buf.getvalue();Image.open(io.BytesIO(blob)).verify();(O/f'Figure_{n}.png').write_bytes(blob);fig.savefig(O/f'Figure_{n}.tiff',dpi=600,bbox_inches='tight',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
a=f[f.subset=='Full'].sort_values('count',ascending=True,kind='stable');fig,ax=plt.subplots(figsize=(8,5));ax.barh(a.role,a.percent,color='.5',edgecolor='black');ax.set_xlim(0,54);ax.set_xlabel('Episodes reporting the role (%)')
for i,r in enumerate(a.itertuples()):ax.text(r.percent+.5,i,f'{r.count}/{r.denominator} ({r.percent:.1f}%)',va='center',fontsize=10.5)
ax.spines[['top','right']].set_visible(False);fig.tight_layout();save(fig,3)
mat=[];labels=[]
for c,n in zip(roles,names):
 rr=[];ll=[]
 for elig,res in [('education_eligible','learning_result'),('exposure_eligible','exposure_result'),('clinical_eligible','clinical_result')]:
  a=d[d[c].eq(1)&d[elig]];N=len(a);k=int(a[res].sum());rr.append(100*k/N if N else np.nan);ll.append(f'{k}/{N}\n({100*k/N:.1f}%)' if N else 'Not applicable')
 mat.append(rr);labels.append(ll)
fig,ax=plt.subplots(figsize=(8.3,5.8));ax.imshow(np.ma.masked_invalid(mat),cmap='Greys',vmin=0,vmax=65,aspect='auto');ax.set_xticks(range(3),['Knowledge or learning','Exposure','Clinical health']);ax.set_yticks(range(9),names);ax.set_title('Reported measurements / relevant episodes within each role',fontsize=10)
for i in range(9):
 for j in range(3):ax.text(j,i,labels[i][j],ha='center',va='center',fontsize=10.5)
ax.tick_params(length=0);fig.tight_layout();save(fig,4)
fig,ax=plt.subplots(figsize=(8.3,6));sn=list(sets);arr=np.array([[f[(f.role==n)&(f.subset==s)].percent.iloc[0] for s in sn] for n in names]);ax.imshow(arr,cmap='Greys',vmin=0,vmax=65,aspect='auto');ax.set_yticks(range(9),names);ax.set_xticks(range(len(sn)),[s.replace(' ','\n')+'\nN='+str(int(np.sum(sets[s]))) for s in sn],fontsize=10);ax.set_title('Role frequencies under documentary and geographical restrictions',fontsize=10)
for i,n in enumerate(names):
 for j,s in enumerate(sn):
  z=f[(f.role==n)&(f.subset==s)].iloc[0];ax.text(j,i,f'{z["count"]}/{z.denominator}\n{z.percent:.1f}%',ha='center',va='center',fontsize=10.5,color='white' if z.percent>42 else 'black')
ax.tick_params(length=0);fig.tight_layout();save(fig,5)
summary=dict(N=len(d),URLs=d.source_url.nunique(),indicators=len(m),role_assignments=int(d.role_count.sum()),multirole=int(d.role_count.ge(2).sum()),known_year=int(pd.to_numeric(d.activity_year,errors='coerce').notna().sum()),subsets={s:int(np.sum(v)) for s,v in sets.items()},provinces=d.activity_province.value_counts().to_dict(),source_types=d.source_type.value_counts().to_dict(),evidence=d.evidence_category.value_counts().to_dict())
(O/'Analysis_Summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print(e.to_string(index=False));print(f.to_string(index=False))
assert len(d)==34 and d.record_id.nunique()==34 and len(m)==46
assert len(learn)==5 and d.education_eligible.sum()==18
assert int(d[roles].sum().sum())==67 and int(d.direct.sum())==29
